import '@/styles/globals.css';
// Redesign 2026-09 — Modernist design tokens for the new surfaces, scoped
// entirely under a `.p360` wrapper class so they never affect the
// pre-redesign UI (see styles/plot360-redesign.css and ARCHITECTURE.md).
import '@/styles/plot360-redesign.css';
import { Archivo } from 'next/font/google';

// Redesign 2026-09 (round 33) — "Implementation Change List" item 4:
// Archivo was only ever loaded inside components/marketing/LandingPage.tsx
// (a client component), so every OTHER `.p360` screen — including
// CustomerHeader.tsx and CustomerHome.tsx, the two most-used customer
// screens — silently fell back to system-ui, since `--p360-font-archivo`
// (the CSS variable `--font-heading`/`--font-body` in
// plot360-redesign.css actually reads) was never set outside the landing
// page's own subtree. Loading it once here, on the root layout, makes it
// available everywhere `.p360` is used. Same config as before (just
// relocated) — see LandingPage.tsx for where this used to live.
const archivo = Archivo({
  subsets: ['latin'],
  weight: ['400', '600', '800'],
  variable: '--p360-font-archivo',
  display: 'swap',
});

export const metadata = {
  title: 'Plot360',
  description: 'Register, verify, and track your properties.',
  // Android app (TWA) — app/manifest.ts is picked up automatically by
  // Next; this just names the app on "Add to home screen" / iOS.
  applicationName: 'Plot360',
  appleWebApp: { capable: true, title: 'Plot360', statusBarStyle: 'default' as const },
};

export const viewport = {
  themeColor: '#1e3a5f',
};

// Android app (TWA) — customer-only "app mode". The app launches at
// /app-launch, which lands on /dashboard or /login with `?source=app`;
// TWA launches (including App Links from emails) also arrive with an
// `android-app://in.plot360.app` referrer. Either marks this browser tab
// as the app via sessionStorage (per-tab, so it never leaks into the
// user's normal Chrome tabs even though TWA shares Chrome's cookies).
// In app mode: the marketing landing page is skipped, and any admin /
// agent / agent-magic-link route is swapped for /app-only before it
// paints. It must not touch the <html>/<body> attributes React renders
// (e.g. adding a class) — that causes a hydration mismatch. Runs inline in <head> so there's no flash of the blocked page.
// This is UX gating only — real access control stays in proxy.ts and the
// page-level guards.
const APP_MODE_SCRIPT = `(function(){try{
var s=window.sessionStorage,q=new URLSearchParams(location.search);
var app=q.get('source')==='app'||document.referrer.indexOf('android-app://in.plot360.app')===0||s.getItem('p360_app')==='1';
if(!app)return;
s.setItem('p360_app','1');
var p=location.pathname;
if(p==='/'){location.replace('/app-launch');return;}
if(/^\\/(admin|agent|m)(\\/|$)/.test(p)){location.replace('/app-only');}
}catch(e){}})();`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={archivo.variable}>
      <head>
        <script dangerouslySetInnerHTML={{ __html: APP_MODE_SCRIPT }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
